Blackjack 0.1.0 -- for SPT 4.1.3
===================================

WHAT THIS IS
    A server mod only. There is no client plugin yet, so there is nothing to
    play in the game itself. What you can test is that the server loads it and
    that its routes answer.

INSTALLING
    Stop the server, then extract this archive into your SPT folder -- the one
    holding SPT_Runtime. The files belong at:

        SPT_Runtime\user\mods\Blackjack\

    Start the server. "Blackjack" should appear in the mod list at startup.

IF IT DOES NOT APPEAR
    The mod declares SptVersion "~4.1.3", which means 4.1.3 or later 4.1.x.
    On anything outside that range the server loads it silently and logs
    nothing at all, which looks identical to the mod not being there.

CHECKING IT ANSWERS
    scripts\smoke.ps1 -SessionId <your profile id> -PingOnly

    That touches no money. It proves the mod loaded, the route is reachable,
    the session resolved and the profile can be read. Run it before anything
    that moves currency.

    The session id is your profile's filename in
    SPT_Runtime\user\profiles\ , without the .json.

LOGGING
    config.json sets the log level. Turn it up before reporting anything --
    the mod reports every currency movement and the reason for it.

WHAT HAS AND HAS NOT BEEN VERIFIED
    Verified: 103 unit tests over the rules and the money flow; and every SPT
    API this mod calls resolves against 4.1.3's own assemblies, along with all
    six wallet item templates.

    Not verified: anything actually running. No profile has been touched by
    this mod. Treat the first run as a test and use a profile you can afford
    to lose.

    Symbols (.pdb) ship on purpose -- a stack trace without line numbers is
    the difference between a fixable report and a shrug.

https://github.com/JoelHauser/Blackjack
