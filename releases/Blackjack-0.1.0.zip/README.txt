Blackjack 0.1.0 -- a card table for the SPT hideout
===================================================

Built for SPT 4.1.3. The mod refuses to load outside 4.1.x.

INSTALL
  Extract into your SPT folder so the files land in:
      <SPT>\user\mods\Blackjack\

  Server mod only. There is no client plugin yet, so there is nothing to
  play in game -- this build exists to prove the server half works.

FIRST RUN
  Start the server and look for a banner:

      [Blackjack] v0.1.0 loaded -- built for SPT ~4.1.3

  No banner means the mod was rejected before it ran, which is almost
  always the SPT version gate. Nothing else will work until it appears.

  Then, with the server running:

      scripts\smoke.ps1 -SessionId <your-profile-id> -PingOnly

  That touches no money. It reports whether the route is reachable, the
  session resolved, and the profile's currency can be read. Only run it
  without -PingOnly once that passes.

LOGGING
  Every line is prefixed [Blackjack] so it can be filtered.
  config.json turns verbose logging off once things work. Leave it on
  for now -- it logs every request and every rouble.

WHAT IS UNPROVEN
  No part of this has run against a real SPT server. The currency
  handling in particular has never touched a real profile. It checks its
  own arithmetic after every move and logs a mismatch, so a silent
  failure should announce itself rather than quietly shorting you.

  Back up your profile before betting anything you would miss.

  https://github.com/JoelHauser/Blackjack
